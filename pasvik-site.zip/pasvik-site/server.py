import argparse
import hashlib
import json
import logging
import re
import tempfile
from datetime import datetime, timezone
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from pypdf import PdfReader
from pypdf.errors import PyPdfError


ROOT = Path(__file__).resolve().parent
MAX_BYTES = 100 * 1024 * 1024
CHUNK_SIZE = 1024 * 1024
UPLOADS = '/api/uploads'
PDF_ROUTE = re.compile(r'/api/uploads/([a-f0-9]{64})\.pdf')
FILE_ID = re.compile(r'[a-f0-9]{64}')
LOGGER = logging.getLogger(__name__)


class UploadError(Exception):
    def __init__(self, message, status=HTTPStatus.BAD_REQUEST):
        super().__init__(message)
        self.status = status


def safe_filename(name):
    name = name.replace('\\', '/').rsplit('/', 1)[-1].strip()
    name = ''.join(char for char in name if char.isprintable())
    if len(name) <= 4 or not name.lower().endswith('.pdf'):
        raise UploadError('Выберите файл в формате PDF.')
    return name[:196] + '.pdf' if len(name) > 200 else name


def pdf_pages(path):
    try:
        with path.open('rb') as stream:
            if not stream.read(1024).lstrip().startswith(b'%PDF-'):
                raise UploadError('Файл не похож на PDF. Выберите другой файл.')
            stream.seek(0)
            reader = PdfReader(stream)
            if reader.is_encrypted:
                raise UploadError('PDF защищён паролем. Загрузите незашифрованную копию.')
            pages = len(reader.pages)
    except (PyPdfError, RecursionError, ValueError, TypeError, KeyError, IndexError) as error:
        raise UploadError('PDF повреждён или не читается. Выберите другой файл.') from error
    if not pages:
        raise UploadError('В PDF нет страниц.')
    return pages


def read_metadata(directory):
    return json.loads((directory / 'metadata.json').read_text(encoding='utf-8'))


def save_upload(uploads_dir, stream, size, filename):
    digest = hashlib.sha256()
    with tempfile.TemporaryDirectory(prefix='.incoming-', dir=uploads_dir) as temp:
        staging = Path(temp) / 'volume'
        staging.mkdir()
        pdf = staging / 'document.pdf'
        with pdf.open('wb') as target:
            remaining = size
            while remaining:
                chunk = stream.read(min(remaining, CHUNK_SIZE))
                if not chunk:
                    raise UploadError('Загрузка прервалась. Попробуйте ещё раз.')
                target.write(chunk)
                digest.update(chunk)
                remaining -= len(chunk)

        file_id = digest.hexdigest()
        destination = uploads_dir / file_id
        if destination.is_dir():
            return read_metadata(destination), True

        volume = {
            'id': file_id,
            'filename': filename,
            'pages': pdf_pages(pdf),
            'size': size,
            'uploaded_at': datetime.now(timezone.utc).isoformat(),
            'pdf_url': f'.{UPLOADS}/{file_id}.pdf',
        }
        (staging / 'metadata.json').write_text(json.dumps(volume, ensure_ascii=False), encoding='utf-8')
        try:
            staging.rename(destination)
        except OSError:
            if destination.is_dir():
                return read_metadata(destination), True
            raise
        return volume, False


class PasvikHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, uploads_dir, **kwargs):
        self.uploads_dir = uploads_dir
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()

    def send_json(self, status, payload, head=False):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def do_POST(self):
        route = urlsplit(self.path)
        if route.path != UPLOADS:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            filename = safe_filename(parse_qs(route.query).get('filename', [''])[0])
            if self.headers.get_content_type() != 'application/pdf':
                raise UploadError('Поддерживаются только PDF.', HTTPStatus.UNSUPPORTED_MEDIA_TYPE)
            try:
                size = int(self.headers.get('Content-Length', 0))
            except ValueError as error:
                raise UploadError('Некорректный размер файла.') from error
            if size <= 0:
                raise UploadError('Файл пуст. Выберите другой PDF.')
            if size > MAX_BYTES:
                raise UploadError('Размер файла превышает 100 МБ.', HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            self.connection.settimeout(90)
            volume, duplicate = save_upload(self.uploads_dir, self.rfile, size, filename)
        except UploadError as error:
            self.send_json(error.status, {'error': str(error)})
            return
        except OSError:
            LOGGER.exception('Unable to save PDF')
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {'error': 'Не удалось сохранить PDF. Попробуйте ещё раз.'})
            return
        self.send_json(HTTPStatus.OK if duplicate else HTTPStatus.CREATED, {'volume': volume, 'duplicate': duplicate})

    def send_head(self):
        route = urlsplit(self.path).path
        if route == UPLOADS:
            volumes = [read_metadata(path) for path in self.uploads_dir.iterdir() if path.is_dir() and FILE_ID.fullmatch(path.name)]
            self.send_json(HTTPStatus.OK, {'volumes': volumes}, head=self.command == 'HEAD')
            return None
        match = PDF_ROUTE.fullmatch(route)
        if match:
            pdf = self.uploads_dir / match[1] / 'document.pdf'
            if not pdf.is_file():
                self.send_error(HTTPStatus.NOT_FOUND)
                return None
            stream = pdf.open('rb')
            self.send_response(HTTPStatus.OK)
            self.send_header('Content-Type', 'application/pdf')
            self.send_header('Content-Length', str(pdf.stat().st_size))
            self.end_headers()
            return stream
        if route == '/':
            self.path = '/index.html'
        path = Path(self.translate_path(self.path)).resolve()
        allowed = (
            path in (ROOT / 'index.html', ROOT / 'data/catalog.json')
            or path.is_relative_to(ROOT / 'static')
            or (path.is_relative_to(ROOT / 'data/sources') and path.suffix.lower() == '.pdf')
        )
        if not allowed or not path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return None
        return super().send_head()


def main():
    parser = argparse.ArgumentParser(description='Локальный сервер каталога Пасвик')
    parser.add_argument('--bind', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--uploads-dir', type=Path, default=ROOT / 'data/uploads')
    args = parser.parse_args()
    uploads_dir = args.uploads_dir.resolve()
    uploads_dir.mkdir(parents=True, exist_ok=True)
    handler = partial(PasvikHandler, uploads_dir=uploads_dir)
    with ThreadingHTTPServer((args.bind, args.port), handler) as server:
        print(f'Пасвик · http://{args.bind}:{server.server_port}/', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
